package org.tzi.use.main.shell;

public class NoSystemException extends Exception {
	/**
	 * To get rid of the warning...
	 */
	private static final long serialVersionUID = 1L;
}